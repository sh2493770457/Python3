
python SmbtouchScanner.py 20 192.168.1.1 192.168.1.254