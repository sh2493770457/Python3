Github:
https://github.com/abc123info/EquationToolsGUI